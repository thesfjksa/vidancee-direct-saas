"use strict";

// Launches the actual website, never routes credentials or session data through CMMTools.
const STUDIO_URL = "https://aivid.dev/";
const START_PAGE = chrome.runtime.getURL("loading.html");
let pendingLaunch = null;

async function launchStudio() {
  if (pendingLaunch) return pendingLaunch;
  pendingLaunch = (async () => {
    const stored = await chrome.storage.session.get("studioWindowId");
    if (Number.isInteger(stored.studioWindowId)) {
      try {
        await chrome.windows.update(stored.studioWindowId, { focused: true });
        return { reused: true };
      } catch (_) { /* Window no longer exists. */ }
    }

    // Open a local, branded screen immediately rather than waiting for a network request.
    const created = await chrome.windows.create({
      url: START_PAGE,
      type: "popup",
      focused: true,
      width: 1350,
      height: 860
    });
    if (!created || !Number.isInteger(created.id)) {
      throw new Error("Browser could not create the Video Studio window.");
    }
    await chrome.storage.session.set({studioWindowId: created.id});
    return {reused: false};
  })();

  try { return await pendingLaunch; }
  finally { pendingLaunch = null; }
}

chrome.windows.onRemoved.addListener(async windowId => {
  try {
    const stored = await chrome.storage.session.get("studioWindowId");
    if (stored.studioWindowId === windowId) {
      await chrome.storage.session.remove("studioWindowId");
    }
  } catch (error) { console.debug("Studio cleanup:", error); }
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === "CMMTOOLS_OPEN_STUDIO") {
    launchStudio()
      .then(result => sendResponse({ok: true, ...result}))
      .catch(error => sendResponse({ok: false, error: error.message}));
    return true;
  }
  if (message?.type === "CMMTOOLS_START_NAVIGATION") {
    (async () => {
      // Only our own splash page, inside the launched popup, may start navigation.
      if (!sender.tab || sender.url !== START_PAGE) {
        throw new Error("Launch request did not come from the Video Studio window.");
      }
      const {studioWindowId} = await chrome.storage.session.get("studioWindowId");
      if (sender.tab.windowId !== studioWindowId) {
        throw new Error("Studio popup could not be verified.");
      }
      await chrome.tabs.update(sender.tab.id, {url: STUDIO_URL});
      return {ok: true};
    })()
      .then(result => sendResponse(result))
      .catch(error => sendResponse({ok: false, error: error.message}));
    return true;
  }
  return false;
});

chrome.runtime.onMessageExternal.addListener((message, sender, sendResponse) => {
  if (message?.type !== "CMMTOOLS_OPEN_AIVID") return false;
  if (!sender.url || !/^https?:\/\//i.test(sender.url)) {
    sendResponse({ok: false, error: "Invalid calling page."});
    return false;
  }
  // Only sites in manifest.externally_connectable can reach this listener.
  launchStudio()
    .then(result => sendResponse({ok: true, ...result}))
    .catch(error => sendResponse({ok: false, error: error.message}));
  return true;
});
