"use strict";
const heading = document.getElementById("heading");
const detail = document.getElementById("detail");
const retry = document.getElementById("retry");
let navigating = false;

function continueToStudio() {
  if (navigating) return;
  navigating = true;
  retry.hidden = true;
  document.body.classList.remove("error");
  detail.textContent = "Opening the editor…";
  chrome.runtime.sendMessage({type:"CMMTOOLS_START_NAVIGATION"}, response => {
    const error = chrome.runtime.lastError?.message || (!response?.ok && response?.error);
    if (error || !response?.ok) {
      navigating = false;
      document.body.classList.add("error");
      heading.textContent = "Studio needs another try";
      detail.textContent = error || "Unable to open the editor.";
      retry.hidden = false;
    }
  });
}
retry.addEventListener("click", continueToStudio);
// Let a few animation frames paint before navigating to the remote website.
setTimeout(continueToStudio, 850);
