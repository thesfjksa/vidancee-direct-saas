# CMMTools Video Studio Launcher v1.5

Standalone Chrome / Edge extension with your **uploaded CMMTools logo** and **instant animated launch feedback**.

## Features introduced in v1.4 (from v1.3)

- The header **credit-balance pill** (for example **0 credits**) stays visible but cannot be activated by mouse, touch, or Enter/Space keyboard input; it will not open the credit purchase modal through that header control. This targets only the compact credit balance control near the top of the app.
- A **Disable credit-purchase button** toggle is enabled by default in Extension options, and can be switched off if you need normal account access.

## Features introduced in v1.3

- The **extension toolbar icon** and the website's replacement favicon now use the CMMTools monogram cropped from your uploaded logo.
- Clicking the toolbar icon now opens a **small, animated CMMTools launcher immediately** (the old extension silently waited for a background worker before showing a window). It automatically launches the Studio; users do not need to click a second button.
- The separate app-style Studio window begins on a **branded CMMTools animated splash screen**, then navigates to the real service after a brief transition.
- Same popup-window mode (no ordinary address bar), personal AIVID login, and existing Billing / Referral / navigation-branding display rules as v1.2. No RDP or Playwright.
- The optional button example sets a visible "Opening…" status as soon as clicked.

## New in v1.5

- Hide the site footer, its links, and its provider logo, including standard semantic footers and common styled footer containers. Enabled by default; switch it off from **Extension options** if needed.
- Hide the header/sidebar AIVID brand lockup, including the **AIVid Dev** text + adjacent icon as shown in the user's screenshot. Keeps the rest of the navigation usable.
- Preserves Billing / Referral hiding, header credit-button lock, CMMTools favicon/title, uploaded logo and animated launcher.
- **Allow in Incognito / InPrivate** remains available under browser extension Details; it must be enabled manually by the user. The extension cannot force-enable it. The `incognito` manifest setting is intentionally left at the browser default.

## Installation / update

1. Extract the ZIP into a permanent folder on the computer.
2. If replacing a previous version: to **retain the existing extension ID**, overwrite the files inside the *same extension folder you originally loaded*, then press **Reload** at `edge://extensions` or `chrome://extensions` and reopen Studio. Otherwise you may remove the old extension and load this new `extension` folder as a new extension (the ID and local settings could change).
3. For first-time installation, enable Developer mode, choose **Load unpacked**, and select the extracted `extension` folder (where `manifest.json` is).
4. Pin the CMMTools extension icon to your browser toolbar and click it. The small animated launcher appears instantly and opens the app-style Studio window automatically.
5. For settings, visit extension **Details → Extension options**. Billing / Referral / header branding / footer hiding and credit-balance button lock are enabled by default. Custom CSS is optional.

## Optional CMMTools-site button

To launch from the CMMTools frontend, replace `https://cmmtools.example/*` in `extension/manifest.json` with your *actual* HTTPS origin, reload the extension, copy the ID from the extensions page, and update `integration/CMMTOOLS_BUTTON.html` with it. Embed that handler or adapt it to your existing frontend.

## What users see / don't see

The initial splash, toolbar icon, and launcher branding use the uploaded CMMTools logo, and page-level title/favicon/navigation text may be customized locally. In the standalone popup **the normal URL bar is not shown**.

This **does not disguise the true site origin**, guarantee the original service name cannot appear, or restrict access to hidden pages. A website may set its title or branding briefly before extension customization; login redirects, site legal notices, security interfaces, address-origin disclosure, browser inspection, and direct URLs may reveal the domain. Users log in on the actual provider site; this extension does **not** collect cookies or passwords and does not bypass any login protections.

## File map

- `extension/manifest.json` — MV3 manifest, launcher icon and permissions
- `extension/brand/` — generated icons and cropped wordmark from your supplied image
- `extension/launcher.html`, `launcher.js`, `launch-ui.css` — immediate animated toolbar launcher
- `extension/loading.html`, `loading.js` — animated splash in the standalone app window
- `extension/background.js` — creates or focuses a single popup; navigates the splash to the real website
- `extension/studio.js`, `studio.css` — existing Billing, Referral, navigation and title modifications
- `extension/options.html`, `options.js` — settings page
- `integration/CMMTOOLS_BUTTON.html` — optional website button

## Verification and limits

All JS files were checked for syntax and the packaged manifest was validated. (See testing report in chat for any browser-test status.) Your exact signed-in provider site, login, and page layout should be tested on your Edge/Chrome machine; layout selectors and timing can vary.

## Important limits of credit purchase lock

This is a **local visual interaction lock**, not an account permission or a billing security control. It blocks use of the header balance pill within the customized page, but other routes, links, accounts, devices or application updates could still offer purchases. For effective account-level purchase restrictions, use the provider’s official controls where available. An update of the provider UI may require adjusting the selector logic. The exact authenticated UI has not been validated.

## Footer detection limitations

This is a visual CSS/DOM customization tested against a mock page. If a provider renders footer links in a non-semantic wrapper without footer-related attributes/classes, they may remain visible until a selector is adapted to the live layout. Hidden pages remain accessible via direct navigation. Changes to third-party site markup can break selectors.
